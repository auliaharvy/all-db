--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2 (Debian 15.2-1.pgdg110+1)
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dev_pms;
--
-- Name: dev_pms; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE dev_pms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\connect dev_pms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: log_trx_all_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_trx_all_transaction (
    id bigint NOT NULL,
    log_number character varying(100),
    id_sjp bigint,
    created_by bigint,
    id_sjp_status bigint,
    id_pallet_transfer bigint,
    id_claim_pallet bigint,
    id_biaya_sewa bigint,
    id_change_quota bigint,
    id_new_pallet bigint,
    id_new_pallet_realisation bigint,
    id_change_destination bigint,
    id_change_truck bigint,
    transaction character varying(100),
    no_do character varying(100),
    new_no_do character varying(100),
    status character varying(100),
    sender_reporter character varying(100),
    receiver_approver character varying(100),
    company_departure character varying(100),
    company_destination character varying(100),
    company_new_destination character varying(100),
    company_transporter character varying(100),
    company character varying(100),
    truck_number character varying(100),
    truck_number_new character varying(100),
    driver_name character varying(100),
    driver_name_new character varying(100),
    good_pallet bigint,
    tbr_pallet bigint,
    ber_pallet bigint,
    missing_pallet bigint,
    sending_approval character varying(250),
    receiver_approval character varying(250),
    reason character varying(300),
    note character varying(300),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    trx_number character varying,
    price bigint
);


--
-- Name: TABLE log_trx_all_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.log_trx_all_transaction IS 'Table ini digunakan untuk menyimpan log seluruh transaksi dalam Pallet Management System';


--
-- Name: log_trx_all_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.log_trx_all_transaction ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.log_trx_all_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_companies (
    id bigint NOT NULL,
    id_organization bigint,
    id_company_type bigint,
    name character varying(100),
    code character varying(100),
    address character varying(250),
    city character varying(150),
    phone character varying(100),
    email character varying(100),
    tag character varying(100),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    pallet_quota integer DEFAULT 0,
    dist_name character varying(50),
    dist_code character varying(30)
);


--
-- Name: mst_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_companies ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_company_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_company_type (
    id bigint NOT NULL,
    name character varying(100),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer
);


--
-- Name: mst_company_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_company_type ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_company_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_driver; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_driver (
    id bigint NOT NULL,
    id_company bigint,
    name character varying(100),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0
);


--
-- Name: mst_driver_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_driver ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_driver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_organization (
    id bigint NOT NULL,
    name character varying(100),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0
);


--
-- Name: mst_organization_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_organization ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_pallet (
    id bigint NOT NULL,
    name character varying(100),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer
);


--
-- Name: mst_pallet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_pallet ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_pallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_pallet_mst_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_pallet_mst_companies (
    mst_pallet_id bigint,
    mst_companies_id bigint,
    quantity integer
);


--
-- Name: mst_truck; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_truck (
    id bigint NOT NULL,
    id_company bigint,
    license_plate character varying(100),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0,
    transporter_code character varying(100),
    transporter_name character varying(100)
);


--
-- Name: mst_truck_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_truck ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_truck_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mst_trx_number; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mst_trx_number (
    id bigint NOT NULL,
    trx_type character varying(100),
    code character varying(100),
    month character varying(100),
    year character varying(100),
    increment_number bigint
);


--
-- Name: mst_trx_number_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mst_trx_number ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mst_trx_number_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(200),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0
);


--
-- Name: permissions_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_seq OWNED BY public.permissions.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    token text,
    user_id integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: role_has_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_has_permission (
    id_role bigint,
    id_permission bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted bigint DEFAULT '0'::bigint
);


--
-- Name: roles_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint DEFAULT nextval('public.roles_seq'::regclass) NOT NULL,
    name character varying(100),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted bigint DEFAULT 0 NOT NULL
);


--
-- Name: trx_change_destination; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_change_destination (
    id bigint NOT NULL,
    id_sjp bigint,
    id_company_from bigint,
    id_company_to bigint,
    no_do_from character varying(100),
    no_do_to character varying(100),
    reason character varying(200),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer
);


--
-- Name: trx_change_destination_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_change_destination ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_change_destination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_change_quota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_change_quota (
    id bigint NOT NULL,
    id_company_requester bigint,
    id_requester bigint,
    id_approver bigint,
    status integer DEFAULT 0,
    note character varying(400),
    reason character varying(200),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0,
    trx_number character varying(100),
    type integer DEFAULT 0,
    quantity integer DEFAULT 0,
    approved_quantity integer DEFAULT 0
);


--
-- Name: trx_change_quota_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_change_quota ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_change_quota_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_change_truck; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_change_truck (
    id bigint NOT NULL,
    id_sjp bigint,
    id_truck_from bigint,
    id_truck_to bigint,
    id_driver_from bigint,
    new_driver bit varying(200),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer
);


--
-- Name: trx_change_truck_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_change_truck ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_change_truck_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_claim_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_claim_pallet (
    id bigint NOT NULL,
    id_company_distributor bigint,
    id_user_manager bigint,
    id_user_distributor bigint,
    status integer,
    reason_manager character varying(200),
    reason_distributor character varying(200),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    price bigint DEFAULT 0,
    trx_number character varying(100),
    photo character varying(255)
);


--
-- Name: COLUMN trx_claim_pallet.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_claim_pallet.status IS '0: draft
1: approved manager
2: reject manager
3: approved distributor
4. reject manager';


--
-- Name: COLUMN trx_claim_pallet.photo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_claim_pallet.photo IS 'menampung data photo';


--
-- Name: trx_claim_pallet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_claim_pallet ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_claim_pallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_claim_pallet_mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_claim_pallet_mst_pallet (
    trx_claim_pallet_id bigint,
    mst_pallet_id bigint,
    quantity bigint
);


--
-- Name: trx_damaged_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_damaged_pallet (
    id bigint NOT NULL,
    id_company bigint,
    id_user_reporter bigint,
    trx_number character varying(100),
    qty_tbr_pallet bigint,
    note character varying(255),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0
);


--
-- Name: trx_damaged_pallet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_damaged_pallet ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_damaged_pallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_new_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_new_pallet (
    id bigint NOT NULL,
    id_trx_change_quota bigint,
    id_company_workshop bigint,
    qty_request_pallet integer,
    qty_ready_pallet integer DEFAULT 0,
    status integer DEFAULT 0,
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0,
    trx_number character varying(100)
);


--
-- Name: COLUMN trx_new_pallet.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_new_pallet.status IS '0: draft
1: Process
3: Selesai';


--
-- Name: trx_new_pallet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_new_pallet ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_new_pallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_new_pallet_realisation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_new_pallet_realisation (
    id bigint NOT NULL,
    id_trx_new_pallet bigint,
    qty_pallet integer,
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0,
    trx_number character varying(100)
);


--
-- Name: trx_new_pallet_realisation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_new_pallet_realisation ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_new_pallet_realisation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_pallet_transfer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_pallet_transfer (
    id bigint NOT NULL,
    id_company_departure bigint,
    id_company_destination bigint,
    id_user_checker_sender bigint,
    id_user_checker_receiver bigint,
    id_company_transporter bigint,
    id_truck bigint,
    id_driver bigint,
    second_driver character varying(200),
    trx_code character varying(100),
    status integer,
    reason character varying(200),
    note character varying(300),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    id_user_approver integer
);


--
-- Name: trx_pallet_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_pallet_transfer ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_pallet_transfer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_pallet_transfer_mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_pallet_transfer_mst_pallet (
    trx_pallet_transfer_id bigint,
    mst_pallet_id bigint,
    quantity bigint
);


--
-- Name: trx_pengajuan_sewa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_pengajuan_sewa (
    id bigint NOT NULL,
    id_company_distributor bigint,
    id_user_manager bigint,
    id_user_distributor bigint,
    price bigint,
    total bigint,
    status integer,
    reason_manager character varying(200),
    reason_distributor character varying(200),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    trx_number character varying(100),
    photo character varying(255)
);


--
-- Name: COLUMN trx_pengajuan_sewa.photo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_pengajuan_sewa.photo IS 'menampung data photo';


--
-- Name: trx_pengajuan_sewa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_pengajuan_sewa ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_pengajuan_sewa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_pengajuan_sewa_mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_pengajuan_sewa_mst_pallet (
    trx_pengajuan_sewa_id bigint,
    mst_pallet_id bigint,
    quantity bigint DEFAULT 0
);


--
-- Name: trx_repaired_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_repaired_pallet (
    id bigint NOT NULL,
    id_company bigint,
    id_user_reporter bigint,
    trx_number character varying(100),
    qty_good_pallet bigint,
    note character varying(255),
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer DEFAULT 0
);


--
-- Name: trx_repaired_pallet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_repaired_pallet ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_repaired_pallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_sjp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_sjp (
    id bigint NOT NULL,
    id_departure_company bigint,
    id_destination_company bigint,
    id_transporter_company bigint,
    id_truck bigint,
    id_driver bigint,
    second_driver character varying(100),
    trx_number character varying(100),
    no_do character varying(100),
    tonnage integer,
    packaging integer,
    product_quantity integer,
    pallet_quantity integer,
    trx_status integer,
    distribution integer,
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    eta date,
    departure_time date,
    is_multiple character varying DEFAULT 0
);


--
-- Name: trx_sjp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_sjp ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_sjp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_sjp_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_sjp_status (
    id bigint NOT NULL,
    id_sjp bigint,
    id_user_sender bigint,
    id_user_receiver bigint,
    trx_number character varying,
    status integer,
    sending_driver_approval character varying(300),
    receiving_driver_approval character varying(300),
    note character varying(300),
    is_sendback integer,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer
);


--
-- Name: COLUMN trx_sjp_status.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_sjp_status.status IS '0 : send,
1 : received';


--
-- Name: COLUMN trx_sjp_status.is_sendback; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_sjp_status.is_sendback IS '0: transaksi send,
1: transaksi sendback';


--
-- Name: trx_sjp_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_sjp_status ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_sjp_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_sjp_status_mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_sjp_status_mst_pallet (
    trx_sjp_status_id bigint,
    mst_pallet_id bigint,
    quantity bigint
);


--
-- Name: trx_transporter_adjusment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_transporter_adjusment (
    id bigint NOT NULL,
    id_company_transporter bigint,
    id_company bigint,
    id_user_reporter bigint,
    trx_number character varying(100),
    is_from_pool integer,
    created_by bigint,
    updated_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    note character varying(255)
);


--
-- Name: COLUMN trx_transporter_adjusment.is_from_pool; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trx_transporter_adjusment.is_from_pool IS '0:from transporter to pool or distributor,
1: from pool or distributor to transporter';


--
-- Name: trx_transporter_adjusment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.trx_transporter_adjusment ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trx_transporter_adjusment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trx_transporter_adjusment_mst_pallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trx_transporter_adjusment_mst_pallet (
    trx_transporter_adjusment_id bigint,
    mst_pallet_id bigint NOT NULL,
    quantity bigint DEFAULT 0
);


--
-- Name: user_has_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_has_role (
    user_id bigint,
    role_id bigint,
    company_id bigint
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(100),
    email character varying(100),
    fullname character varying(100),
    password text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_deleted integer,
    is_sso integer DEFAULT 0,
    nopeg character varying(20)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: log_trx_all_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_trx_all_transaction (id, log_number, id_sjp, created_by, id_sjp_status, id_pallet_transfer, id_claim_pallet, id_biaya_sewa, id_change_quota, id_new_pallet, id_new_pallet_realisation, id_change_destination, id_change_truck, transaction, no_do, new_no_do, status, sender_reporter, receiver_approver, company_departure, company_destination, company_new_destination, company_transporter, company, truck_number, truck_number_new, driver_name, driver_name_new, good_pallet, tbr_pallet, ber_pallet, missing_pallet, sending_approval, receiver_approval, reason, note, created_at, updated_at, trx_number, price) FROM stdin;
\.
COPY public.log_trx_all_transaction (id, log_number, id_sjp, created_by, id_sjp_status, id_pallet_transfer, id_claim_pallet, id_biaya_sewa, id_change_quota, id_new_pallet, id_new_pallet_realisation, id_change_destination, id_change_truck, transaction, no_do, new_no_do, status, sender_reporter, receiver_approver, company_departure, company_destination, company_new_destination, company_transporter, company, truck_number, truck_number_new, driver_name, driver_name_new, good_pallet, tbr_pallet, ber_pallet, missing_pallet, sending_approval, receiver_approval, reason, note, created_at, updated_at, trx_number, price) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: mst_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_companies (id, id_organization, id_company_type, name, code, address, city, phone, email, tag, created_by, updated_by, created_at, updated_at, is_deleted, pallet_quota, dist_name, dist_code) FROM stdin;
\.
COPY public.mst_companies (id, id_organization, id_company_type, name, code, address, city, phone, email, tag, created_by, updated_by, created_at, updated_at, is_deleted, pallet_quota, dist_name, dist_code) FROM '$$PATH$$/3634.dat';

--
-- Data for Name: mst_company_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_company_type (id, name, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.mst_company_type (id, name, created_at, updated_at, is_deleted) FROM '$$PATH$$/3637.dat';

--
-- Data for Name: mst_driver; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_driver (id, id_company, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.mst_driver (id, id_company, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3642.dat';

--
-- Data for Name: mst_organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_organization (id, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.mst_organization (id, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3638.dat';

--
-- Data for Name: mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_pallet (id, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.mst_pallet (id, name, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3643.dat';

--
-- Data for Name: mst_pallet_mst_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_pallet_mst_companies (mst_pallet_id, mst_companies_id, quantity) FROM stdin;
\.
COPY public.mst_pallet_mst_companies (mst_pallet_id, mst_companies_id, quantity) FROM '$$PATH$$/3644.dat';

--
-- Data for Name: mst_truck; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_truck (id, id_company, license_plate, created_by, updated_by, created_at, updated_at, is_deleted, transporter_code, transporter_name) FROM stdin;
\.
COPY public.mst_truck (id, id_company, license_plate, created_by, updated_by, created_at, updated_at, is_deleted, transporter_code, transporter_name) FROM '$$PATH$$/3639.dat';

--
-- Data for Name: mst_trx_number; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mst_trx_number (id, trx_type, code, month, year, increment_number) FROM stdin;
\.
COPY public.mst_trx_number (id, trx_type, code, month, year, increment_number) FROM '$$PATH$$/3646.dat';

--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.permissions (id, name, created_at, updated_at, is_deleted) FROM '$$PATH$$/3635.dat';

--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, token, user_id, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.refresh_tokens (id, token, user_id, "createdAt", "updatedAt") FROM '$$PATH$$/3659.dat';

--
-- Data for Name: role_has_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_has_permission (id_role, id_permission, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.role_has_permission (id_role, id_permission, created_at, updated_at, is_deleted) FROM '$$PATH$$/3636.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.roles (id, name, created_at, updated_at, is_deleted) FROM '$$PATH$$/3632.dat';

--
-- Data for Name: trx_change_destination; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_change_destination (id, id_sjp, id_company_from, id_company_to, no_do_from, no_do_to, reason, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.trx_change_destination (id, id_sjp, id_company_from, id_company_to, no_do_from, no_do_to, reason, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: trx_change_quota; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_change_quota (id, id_company_requester, id_requester, id_approver, status, note, reason, created_by, updated_by, created_at, updated_at, is_deleted, trx_number, type, quantity, approved_quantity) FROM stdin;
\.
COPY public.trx_change_quota (id, id_company_requester, id_requester, id_approver, status, note, reason, created_by, updated_by, created_at, updated_at, is_deleted, trx_number, type, quantity, approved_quantity) FROM '$$PATH$$/3647.dat';

--
-- Data for Name: trx_change_truck; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_change_truck (id, id_sjp, id_truck_from, id_truck_to, id_driver_from, new_driver, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.trx_change_truck (id, id_sjp, id_truck_from, id_truck_to, id_driver_from, new_driver, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: trx_claim_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_claim_pallet (id, id_company_distributor, id_user_manager, id_user_distributor, status, reason_manager, reason_distributor, created_by, updated_by, created_at, updated_at, is_deleted, price, trx_number, photo) FROM stdin;
\.
COPY public.trx_claim_pallet (id, id_company_distributor, id_user_manager, id_user_distributor, status, reason_manager, reason_distributor, created_by, updated_by, created_at, updated_at, is_deleted, price, trx_number, photo) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: trx_claim_pallet_mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_claim_pallet_mst_pallet (trx_claim_pallet_id, mst_pallet_id, quantity) FROM stdin;
\.
COPY public.trx_claim_pallet_mst_pallet (trx_claim_pallet_id, mst_pallet_id, quantity) FROM '$$PATH$$/3653.dat';

--
-- Data for Name: trx_damaged_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_damaged_pallet (id, id_company, id_user_reporter, trx_number, qty_tbr_pallet, note, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.trx_damaged_pallet (id, id_company, id_user_reporter, trx_number, qty_tbr_pallet, note, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3682.dat';

--
-- Data for Name: trx_new_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_new_pallet (id, id_trx_change_quota, id_company_workshop, qty_request_pallet, qty_ready_pallet, status, created_by, updated_by, created_at, updated_at, is_deleted, trx_number) FROM stdin;
\.
COPY public.trx_new_pallet (id, id_trx_change_quota, id_company_workshop, qty_request_pallet, qty_ready_pallet, status, created_by, updated_by, created_at, updated_at, is_deleted, trx_number) FROM '$$PATH$$/3648.dat';

--
-- Data for Name: trx_new_pallet_realisation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_new_pallet_realisation (id, id_trx_new_pallet, qty_pallet, created_by, updated_by, created_at, updated_at, is_deleted, trx_number) FROM stdin;
\.
COPY public.trx_new_pallet_realisation (id, id_trx_new_pallet, qty_pallet, created_by, updated_by, created_at, updated_at, is_deleted, trx_number) FROM '$$PATH$$/3649.dat';

--
-- Data for Name: trx_pallet_transfer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_pallet_transfer (id, id_company_departure, id_company_destination, id_user_checker_sender, id_user_checker_receiver, id_company_transporter, id_truck, id_driver, second_driver, trx_code, status, reason, note, created_by, updated_by, created_at, updated_at, is_deleted, id_user_approver) FROM stdin;
\.
COPY public.trx_pallet_transfer (id, id_company_departure, id_company_destination, id_user_checker_sender, id_user_checker_receiver, id_company_transporter, id_truck, id_driver, second_driver, trx_code, status, reason, note, created_by, updated_by, created_at, updated_at, is_deleted, id_user_approver) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: trx_pallet_transfer_mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_pallet_transfer_mst_pallet (trx_pallet_transfer_id, mst_pallet_id, quantity) FROM stdin;
\.
COPY public.trx_pallet_transfer_mst_pallet (trx_pallet_transfer_id, mst_pallet_id, quantity) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: trx_pengajuan_sewa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_pengajuan_sewa (id, id_company_distributor, id_user_manager, id_user_distributor, price, total, status, reason_manager, reason_distributor, created_by, updated_by, created_at, updated_at, is_deleted, trx_number, photo) FROM stdin;
\.
COPY public.trx_pengajuan_sewa (id, id_company_distributor, id_user_manager, id_user_distributor, price, total, status, reason_manager, reason_distributor, created_by, updated_by, created_at, updated_at, is_deleted, trx_number, photo) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: trx_pengajuan_sewa_mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_pengajuan_sewa_mst_pallet (trx_pengajuan_sewa_id, mst_pallet_id, quantity) FROM stdin;
\.
COPY public.trx_pengajuan_sewa_mst_pallet (trx_pengajuan_sewa_id, mst_pallet_id, quantity) FROM '$$PATH$$/3655.dat';

--
-- Data for Name: trx_repaired_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_repaired_pallet (id, id_company, id_user_reporter, trx_number, qty_good_pallet, note, created_by, updated_by, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.trx_repaired_pallet (id, id_company, id_user_reporter, trx_number, qty_good_pallet, note, created_by, updated_by, created_at, updated_at, is_deleted) FROM '$$PATH$$/3681.dat';

--
-- Data for Name: trx_sjp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_sjp (id, id_departure_company, id_destination_company, id_transporter_company, id_truck, id_driver, second_driver, trx_number, no_do, tonnage, packaging, product_quantity, pallet_quantity, trx_status, distribution, created_by, updated_by, created_at, updated_at, is_deleted, eta, departure_time, is_multiple) FROM stdin;
\.
COPY public.trx_sjp (id, id_departure_company, id_destination_company, id_transporter_company, id_truck, id_driver, second_driver, trx_number, no_do, tonnage, packaging, product_quantity, pallet_quantity, trx_status, distribution, created_by, updated_by, created_at, updated_at, is_deleted, eta, departure_time, is_multiple) FROM '$$PATH$$/3640.dat';

--
-- Data for Name: trx_sjp_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_sjp_status (id, id_sjp, id_user_sender, id_user_receiver, trx_number, status, sending_driver_approval, receiving_driver_approval, note, is_sendback, created_at, updated_at, is_deleted) FROM stdin;
\.
COPY public.trx_sjp_status (id, id_sjp, id_user_sender, id_user_receiver, trx_number, status, sending_driver_approval, receiving_driver_approval, note, is_sendback, created_at, updated_at, is_deleted) FROM '$$PATH$$/3641.dat';

--
-- Data for Name: trx_sjp_status_mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_sjp_status_mst_pallet (trx_sjp_status_id, mst_pallet_id, quantity) FROM stdin;
\.
COPY public.trx_sjp_status_mst_pallet (trx_sjp_status_id, mst_pallet_id, quantity) FROM '$$PATH$$/3645.dat';

--
-- Data for Name: trx_transporter_adjusment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_transporter_adjusment (id, id_company_transporter, id_company, id_user_reporter, trx_number, is_from_pool, created_by, updated_by, created_at, updated_at, is_deleted, note) FROM stdin;
\.
COPY public.trx_transporter_adjusment (id, id_company_transporter, id_company, id_user_reporter, trx_number, is_from_pool, created_by, updated_by, created_at, updated_at, is_deleted, note) FROM '$$PATH$$/3683.dat';

--
-- Data for Name: trx_transporter_adjusment_mst_pallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trx_transporter_adjusment_mst_pallet (trx_transporter_adjusment_id, mst_pallet_id, quantity) FROM stdin;
\.
COPY public.trx_transporter_adjusment_mst_pallet (trx_transporter_adjusment_id, mst_pallet_id, quantity) FROM '$$PATH$$/3684.dat';

--
-- Data for Name: user_has_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_has_role (user_id, role_id, company_id) FROM stdin;
\.
COPY public.user_has_role (user_id, role_id, company_id) FROM '$$PATH$$/3633.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, fullname, password, created_at, updated_at, is_deleted, is_sso, nopeg) FROM stdin;
\.
COPY public.users (id, username, email, fullname, password, created_at, updated_at, is_deleted, is_sso, nopeg) FROM '$$PATH$$/3631.dat';

--
-- Name: log_trx_all_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_trx_all_transaction_id_seq', 411, true);


--
-- Name: mst_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_companies_id_seq', 90, true);


--
-- Name: mst_company_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_company_type_id_seq', 6, true);


--
-- Name: mst_driver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_driver_id_seq', 30, true);


--
-- Name: mst_organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_organization_id_seq', 20, true);


--
-- Name: mst_pallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_pallet_id_seq', 7, true);


--
-- Name: mst_truck_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_truck_id_seq', 9888, true);


--
-- Name: mst_trx_number_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mst_trx_number_id_seq', 49, true);


--
-- Name: permissions_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_seq', 659, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 1515, true);


--
-- Name: roles_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_seq', 59, true);


--
-- Name: trx_change_destination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_change_destination_id_seq', 1, false);


--
-- Name: trx_change_quota_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_change_quota_id_seq', 43, true);


--
-- Name: trx_change_truck_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_change_truck_id_seq', 1, false);


--
-- Name: trx_claim_pallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_claim_pallet_id_seq', 67, true);


--
-- Name: trx_damaged_pallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_damaged_pallet_id_seq', 23, true);


--
-- Name: trx_new_pallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_new_pallet_id_seq', 23, true);


--
-- Name: trx_new_pallet_realisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_new_pallet_realisation_id_seq', 43, true);


--
-- Name: trx_pallet_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_pallet_transfer_id_seq', 41, true);


--
-- Name: trx_pengajuan_sewa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_pengajuan_sewa_id_seq', 25, true);


--
-- Name: trx_repaired_pallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_repaired_pallet_id_seq', 14, true);


--
-- Name: trx_sjp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_sjp_id_seq', 106, true);


--
-- Name: trx_sjp_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_sjp_status_id_seq', 118, true);


--
-- Name: trx_transporter_adjusment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trx_transporter_adjusment_id_seq', 34, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 90, true);


--
-- Name: mst_truck license_plate_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_truck
    ADD CONSTRAINT license_plate_unique UNIQUE (license_plate) INCLUDE (created_at, updated_at);


--
-- Name: log_trx_all_transaction log_trx_all_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_pkey PRIMARY KEY (id);


--
-- Name: mst_companies mst_companies_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_companies
    ADD CONSTRAINT mst_companies_code_key UNIQUE (code);


--
-- Name: mst_companies mst_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_companies
    ADD CONSTRAINT mst_companies_pkey PRIMARY KEY (id);


--
-- Name: mst_company_type mst_company_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_company_type
    ADD CONSTRAINT mst_company_type_pkey PRIMARY KEY (id);


--
-- Name: mst_driver mst_driver_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_driver
    ADD CONSTRAINT mst_driver_pkey PRIMARY KEY (id);


--
-- Name: mst_organization mst_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_organization
    ADD CONSTRAINT mst_organization_pkey PRIMARY KEY (id);


--
-- Name: mst_pallet mst_pallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_pallet
    ADD CONSTRAINT mst_pallet_pkey PRIMARY KEY (id);


--
-- Name: mst_truck mst_truck_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_truck
    ADD CONSTRAINT mst_truck_pkey PRIMARY KEY (id);


--
-- Name: mst_trx_number mst_trx_number_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_trx_number
    ADD CONSTRAINT mst_trx_number_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: trx_change_destination trx_change_destination_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_destination
    ADD CONSTRAINT trx_change_destination_pkey PRIMARY KEY (id);


--
-- Name: trx_change_quota trx_change_quota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_quota
    ADD CONSTRAINT trx_change_quota_pkey PRIMARY KEY (id);


--
-- Name: trx_change_truck trx_change_truck_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_truck
    ADD CONSTRAINT trx_change_truck_pkey PRIMARY KEY (id);


--
-- Name: trx_claim_pallet trx_claim_pallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet
    ADD CONSTRAINT trx_claim_pallet_pkey PRIMARY KEY (id);


--
-- Name: trx_damaged_pallet trx_damaged_pallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_damaged_pallet
    ADD CONSTRAINT trx_damaged_pallet_pkey PRIMARY KEY (id);


--
-- Name: trx_new_pallet trx_new_pallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_new_pallet
    ADD CONSTRAINT trx_new_pallet_pkey PRIMARY KEY (id);


--
-- Name: trx_new_pallet_realisation trx_new_pallet_realisation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_new_pallet_realisation
    ADD CONSTRAINT trx_new_pallet_realisation_pkey PRIMARY KEY (id);


--
-- Name: trx_pallet_transfer trx_pallet_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_pkey PRIMARY KEY (id);


--
-- Name: trx_pengajuan_sewa trx_pengajuan_sewa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa
    ADD CONSTRAINT trx_pengajuan_sewa_pkey PRIMARY KEY (id);


--
-- Name: trx_repaired_pallet trx_repaired_pallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_repaired_pallet
    ADD CONSTRAINT trx_repaired_pallet_pkey PRIMARY KEY (id);


--
-- Name: trx_sjp trx_sjp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_pkey PRIMARY KEY (id);


--
-- Name: trx_sjp_status trx_sjp_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status
    ADD CONSTRAINT trx_sjp_status_pkey PRIMARY KEY (id);


--
-- Name: trx_transporter_adjusment trx_transporter_adjusment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment
    ADD CONSTRAINT trx_transporter_adjusment_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_un; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_un UNIQUE (username);


--
-- Name: fki_log_trx_all_transaction_id_biaya_sewa_fkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_log_trx_all_transaction_id_biaya_sewa_fkey ON public.log_trx_all_transaction USING btree (id);


--
-- Name: fki_log_trx_all_transaction_id_change_destination_fkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_log_trx_all_transaction_id_change_destination_fkey ON public.log_trx_all_transaction USING btree (id_change_destination);


--
-- Name: fki_log_trx_all_transaction_id_change_quota_fkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_log_trx_all_transaction_id_change_quota_fkey ON public.log_trx_all_transaction USING btree (id_change_quota);


--
-- Name: fki_log_trx_all_transaction_id_new_pallet_fkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_log_trx_all_transaction_id_new_pallet_fkey ON public.log_trx_all_transaction USING btree (id);


--
-- Name: fki_log_trx_all_transaction_id_new_pallet_realisation_fkey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_log_trx_all_transaction_id_new_pallet_realisation_fkey ON public.log_trx_all_transaction USING btree (id);


--
-- Name: fki_t; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_t ON public.log_trx_all_transaction USING btree (id);


--
-- Name: mst_companies company_has_organization; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_companies
    ADD CONSTRAINT company_has_organization FOREIGN KEY (id_organization) REFERENCES public.mst_organization(id) NOT VALID;


--
-- Name: mst_truck company_has_truck; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_truck
    ADD CONSTRAINT company_has_truck FOREIGN KEY (id_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: mst_companies company_has_type; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_companies
    ADD CONSTRAINT company_has_type FOREIGN KEY (id_company_type) REFERENCES public.mst_company_type(id) NOT VALID;


--
-- Name: user_has_role company_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_has_role
    ADD CONSTRAINT company_reference FOREIGN KEY (company_id) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_biaya_sewa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_biaya_sewa_fkey FOREIGN KEY (id_biaya_sewa) REFERENCES public.trx_pengajuan_sewa(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_change_destination_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_change_destination_fkey FOREIGN KEY (id_change_destination) REFERENCES public.trx_change_destination(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_change_quota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_change_quota_fkey FOREIGN KEY (id_change_quota) REFERENCES public.trx_change_quota(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_change_truck_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_change_truck_fkey FOREIGN KEY (id_change_truck) REFERENCES public.trx_change_truck(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_claim_pallet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_claim_pallet_fkey FOREIGN KEY (id_claim_pallet) REFERENCES public.trx_claim_pallet(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_new_pallet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_new_pallet_fkey FOREIGN KEY (id_new_pallet) REFERENCES public.trx_new_pallet(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_new_pallet_realisation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_new_pallet_realisation_fkey FOREIGN KEY (id_new_pallet_realisation) REFERENCES public.trx_new_pallet_realisation(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_pallet_transfer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_pallet_transfer_fkey FOREIGN KEY (id_pallet_transfer) REFERENCES public.trx_pallet_transfer(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_sjp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_sjp_fkey FOREIGN KEY (id_sjp) REFERENCES public.trx_sjp(id) NOT VALID;


--
-- Name: log_trx_all_transaction log_trx_all_transaction_id_sjp_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_trx_all_transaction
    ADD CONSTRAINT log_trx_all_transaction_id_sjp_status_fkey FOREIGN KEY (id_sjp_status) REFERENCES public.trx_sjp_status(id) NOT VALID;


--
-- Name: mst_driver mst_driver_id_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_driver
    ADD CONSTRAINT mst_driver_id_company_fkey FOREIGN KEY (id_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: mst_pallet_mst_companies mst_pallet_mst_companies_mst_companies_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_pallet_mst_companies
    ADD CONSTRAINT mst_pallet_mst_companies_mst_companies_id_fkey FOREIGN KEY (mst_companies_id) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: mst_pallet_mst_companies mst_pallet_mst_companies_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mst_pallet_mst_companies
    ADD CONSTRAINT mst_pallet_mst_companies_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: role_has_permission permission_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permission
    ADD CONSTRAINT permission_reference FOREIGN KEY (id_permission) REFERENCES public.permissions(id) NOT VALID;


--
-- Name: user_has_role role_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_has_role
    ADD CONSTRAINT role_reference FOREIGN KEY (role_id) REFERENCES public.roles(id) NOT VALID;


--
-- Name: role_has_permission role_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permission
    ADD CONSTRAINT role_reference FOREIGN KEY (id_role) REFERENCES public.roles(id) NOT VALID;


--
-- Name: trx_sjp_status sjp_has_sjp_status; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status
    ADD CONSTRAINT sjp_has_sjp_status FOREIGN KEY (id_sjp) REFERENCES public.trx_sjp(id) NOT VALID;


--
-- Name: trx_sjp_status sjp_status_has_user_receiver; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status
    ADD CONSTRAINT sjp_status_has_user_receiver FOREIGN KEY (id_user_receiver) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_sjp_status sjp_status_has_user_sender; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status
    ADD CONSTRAINT sjp_status_has_user_sender FOREIGN KEY (id_user_sender) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_change_destination trx_change_destination_id_company_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_destination
    ADD CONSTRAINT trx_change_destination_id_company_from_fkey FOREIGN KEY (id_company_from) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_change_destination trx_change_destination_id_company_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_destination
    ADD CONSTRAINT trx_change_destination_id_company_to_fkey FOREIGN KEY (id_company_to) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_change_destination trx_change_destination_id_sjp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_destination
    ADD CONSTRAINT trx_change_destination_id_sjp_fkey FOREIGN KEY (id_sjp) REFERENCES public.trx_sjp(id) NOT VALID;


--
-- Name: trx_change_quota trx_change_quota_id_approver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_quota
    ADD CONSTRAINT trx_change_quota_id_approver_fkey FOREIGN KEY (id_approver) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_change_quota trx_change_quota_id_company_requester_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_quota
    ADD CONSTRAINT trx_change_quota_id_company_requester_fkey FOREIGN KEY (id_company_requester) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_change_quota trx_change_quota_id_requester_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_quota
    ADD CONSTRAINT trx_change_quota_id_requester_fkey FOREIGN KEY (id_requester) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_change_truck trx_change_truck_id_driver_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_truck
    ADD CONSTRAINT trx_change_truck_id_driver_from_fkey FOREIGN KEY (id_driver_from) REFERENCES public.mst_driver(id) NOT VALID;


--
-- Name: trx_change_truck trx_change_truck_id_sjp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_truck
    ADD CONSTRAINT trx_change_truck_id_sjp_fkey FOREIGN KEY (id_sjp) REFERENCES public.trx_sjp(id) NOT VALID;


--
-- Name: trx_change_truck trx_change_truck_id_truck_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_truck
    ADD CONSTRAINT trx_change_truck_id_truck_from_fkey FOREIGN KEY (id_truck_from) REFERENCES public.mst_truck(id) NOT VALID;


--
-- Name: trx_change_truck trx_change_truck_id_truck_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_change_truck
    ADD CONSTRAINT trx_change_truck_id_truck_to_fkey FOREIGN KEY (id_truck_to) REFERENCES public.mst_truck(id) NOT VALID;


--
-- Name: trx_claim_pallet trx_claim_pallet_id_company_distributor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet
    ADD CONSTRAINT trx_claim_pallet_id_company_distributor_fkey FOREIGN KEY (id_company_distributor) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_claim_pallet trx_claim_pallet_id_user_distributor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet
    ADD CONSTRAINT trx_claim_pallet_id_user_distributor_fkey FOREIGN KEY (id_user_distributor) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_claim_pallet trx_claim_pallet_id_user_manager_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet
    ADD CONSTRAINT trx_claim_pallet_id_user_manager_fkey FOREIGN KEY (id_user_manager) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_claim_pallet_mst_pallet trx_claim_pallet_mst_pallet_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet_mst_pallet
    ADD CONSTRAINT trx_claim_pallet_mst_pallet_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: trx_claim_pallet_mst_pallet trx_claim_pallet_mst_pallet_trx_claim_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_claim_pallet_mst_pallet
    ADD CONSTRAINT trx_claim_pallet_mst_pallet_trx_claim_pallet_id_fkey FOREIGN KEY (trx_claim_pallet_id) REFERENCES public.trx_claim_pallet(id) NOT VALID;


--
-- Name: trx_damaged_pallet trx_damaged_pallet_id_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_damaged_pallet
    ADD CONSTRAINT trx_damaged_pallet_id_company_fkey FOREIGN KEY (id_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_damaged_pallet trx_damaged_pallet_id_user_reporter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_damaged_pallet
    ADD CONSTRAINT trx_damaged_pallet_id_user_reporter_fkey FOREIGN KEY (id_user_reporter) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_new_pallet trx_new_pallet_id_company_workshop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_new_pallet
    ADD CONSTRAINT trx_new_pallet_id_company_workshop_fkey FOREIGN KEY (id_company_workshop) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_new_pallet trx_new_pallet_id_trx_change_quota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_new_pallet
    ADD CONSTRAINT trx_new_pallet_id_trx_change_quota_fkey FOREIGN KEY (id_trx_change_quota) REFERENCES public.trx_change_quota(id) NOT VALID;


--
-- Name: trx_new_pallet_realisation trx_new_pallet_realisation_id_trx_new_pallet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_new_pallet_realisation
    ADD CONSTRAINT trx_new_pallet_realisation_id_trx_new_pallet_fkey FOREIGN KEY (id_trx_new_pallet) REFERENCES public.trx_new_pallet(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_company_departure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_company_departure_fkey FOREIGN KEY (id_company_departure) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_company_destination_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_company_destination_fkey FOREIGN KEY (id_company_destination) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_company_transporter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_company_transporter_fkey FOREIGN KEY (id_company_transporter) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_driver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_driver_fkey FOREIGN KEY (id_driver) REFERENCES public.mst_driver(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_truck_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_truck_fkey FOREIGN KEY (id_truck) REFERENCES public.mst_truck(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_user_checker_receiver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_user_checker_receiver_fkey FOREIGN KEY (id_user_checker_receiver) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_pallet_transfer trx_pallet_transfer_id_user_checker_sender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer
    ADD CONSTRAINT trx_pallet_transfer_id_user_checker_sender_fkey FOREIGN KEY (id_user_checker_sender) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_pallet_transfer_mst_pallet trx_pallet_transfer_mst_pallet_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer_mst_pallet
    ADD CONSTRAINT trx_pallet_transfer_mst_pallet_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: trx_pallet_transfer_mst_pallet trx_pallet_transfer_mst_pallet_trx_pallet_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pallet_transfer_mst_pallet
    ADD CONSTRAINT trx_pallet_transfer_mst_pallet_trx_pallet_transfer_id_fkey FOREIGN KEY (trx_pallet_transfer_id) REFERENCES public.trx_pallet_transfer(id) NOT VALID;


--
-- Name: trx_pengajuan_sewa trx_pengajuan_sewa_id_company_distributor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa
    ADD CONSTRAINT trx_pengajuan_sewa_id_company_distributor_fkey FOREIGN KEY (id_company_distributor) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_pengajuan_sewa trx_pengajuan_sewa_id_user_distributor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa
    ADD CONSTRAINT trx_pengajuan_sewa_id_user_distributor_fkey FOREIGN KEY (id_user_distributor) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_pengajuan_sewa trx_pengajuan_sewa_id_user_manager_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa
    ADD CONSTRAINT trx_pengajuan_sewa_id_user_manager_fkey FOREIGN KEY (id_user_manager) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_pengajuan_sewa_mst_pallet trx_pengajuan_sewa_mst_pallet_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa_mst_pallet
    ADD CONSTRAINT trx_pengajuan_sewa_mst_pallet_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: trx_pengajuan_sewa_mst_pallet trx_pengajuan_sewa_mst_pallet_trx_pengajuan_sewa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_pengajuan_sewa_mst_pallet
    ADD CONSTRAINT trx_pengajuan_sewa_mst_pallet_trx_pengajuan_sewa_id_fkey FOREIGN KEY (trx_pengajuan_sewa_id) REFERENCES public.trx_pengajuan_sewa(id) NOT VALID;


--
-- Name: trx_repaired_pallet trx_repaired_pallet_id_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_repaired_pallet
    ADD CONSTRAINT trx_repaired_pallet_id_company_fkey FOREIGN KEY (id_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_repaired_pallet trx_repaired_pallet_id_user_reporter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_repaired_pallet
    ADD CONSTRAINT trx_repaired_pallet_id_user_reporter_fkey FOREIGN KEY (id_user_reporter) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_sjp trx_sjp_id_departure_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_id_departure_company_fkey FOREIGN KEY (id_departure_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_sjp trx_sjp_id_destination_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_id_destination_company_fkey FOREIGN KEY (id_destination_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_sjp trx_sjp_id_driver_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_id_driver_fkey FOREIGN KEY (id_driver) REFERENCES public.mst_driver(id) NOT VALID;


--
-- Name: trx_sjp trx_sjp_id_transporter_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_id_transporter_company_fkey FOREIGN KEY (id_transporter_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_sjp trx_sjp_id_truck_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp
    ADD CONSTRAINT trx_sjp_id_truck_fkey FOREIGN KEY (id_truck) REFERENCES public.mst_truck(id) NOT VALID;


--
-- Name: trx_sjp_status_mst_pallet trx_sjp_status_mst_pallet_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status_mst_pallet
    ADD CONSTRAINT trx_sjp_status_mst_pallet_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: trx_sjp_status_mst_pallet trx_sjp_status_mst_pallet_trx_sjp_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_sjp_status_mst_pallet
    ADD CONSTRAINT trx_sjp_status_mst_pallet_trx_sjp_status_id_fkey FOREIGN KEY (trx_sjp_status_id) REFERENCES public.trx_sjp_status(id) NOT VALID;


--
-- Name: trx_transporter_adjusment trx_transporter_adjusment_id_company_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment
    ADD CONSTRAINT trx_transporter_adjusment_id_company_fkey FOREIGN KEY (id_company) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_transporter_adjusment trx_transporter_adjusment_id_company_transporter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment
    ADD CONSTRAINT trx_transporter_adjusment_id_company_transporter_fkey FOREIGN KEY (id_company_transporter) REFERENCES public.mst_companies(id) NOT VALID;


--
-- Name: trx_transporter_adjusment trx_transporter_adjusment_id_user_reporter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment
    ADD CONSTRAINT trx_transporter_adjusment_id_user_reporter_fkey FOREIGN KEY (id_user_reporter) REFERENCES public.users(id) NOT VALID;


--
-- Name: trx_transporter_adjusment_mst_pallet trx_transporter_adjusment_mst_pallet_mst_pallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment_mst_pallet
    ADD CONSTRAINT trx_transporter_adjusment_mst_pallet_mst_pallet_id_fkey FOREIGN KEY (mst_pallet_id) REFERENCES public.mst_pallet(id) NOT VALID;


--
-- Name: trx_transporter_adjusment_mst_pallet trx_transporter_adjusment_mst_trx_transporter_adjusment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trx_transporter_adjusment_mst_pallet
    ADD CONSTRAINT trx_transporter_adjusment_mst_trx_transporter_adjusment_id_fkey FOREIGN KEY (trx_transporter_adjusment_id) REFERENCES public.trx_transporter_adjusment(id) NOT VALID;


--
-- Name: user_has_role user_reference; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_has_role
    ADD CONSTRAINT user_reference FOREIGN KEY (user_id) REFERENCES public.users(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

